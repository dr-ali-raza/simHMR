function etaI = diff_Rotate(t,vI)
global linVelo;
etaI = ForwardRotate(linVelo);