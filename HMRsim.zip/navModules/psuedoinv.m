function A = psuedoinv(B)
A = inv(B'*B)*B';