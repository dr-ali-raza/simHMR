function etaI = diff_Translation(t,vI)
global linVelo b;
etaI = ForwardTranslate(linVelo,b);